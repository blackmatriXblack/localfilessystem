#!/usr/bin/env python3
"""Install dist/locals_filesystem-*.whl over the *installed* fileforge package.

Why this exists
---------------
PyPI still hosts `locals-filesystem` 2.0.0, which was built before the live
tree and "This PC" modules existed.  Running::

    pip install --upgrade locals-filesystem

therefore *downgrades* the package and `fileforge computerui` breaks again with
"invalid choice".  Two things make a plain `pip install` awkward here:

* pip's console-script write uses a rename-to-`.deleteme` step that some
  sandbox / safe-delete shims reject (`SHFileOperationW 失败: 0x2`);
* the generated `fileforge.exe` keeps pointing at `fileforge.cli:main`, which
  is fine -- `cli.main` now forwards to `fileforge.dispatch`, so overwriting
  the package files alone is enough to upgrade every entry point.

This script just unpacks the wheel straight into site-packages and drops stale
bytecode.  No renames, nothing for a shim to block.

Usage
-----
    python install_local.py                  # current interpreter
    python install_local.py --wheel dist/x.whl
    python install_local.py --target <site-packages>
    python install_local.py --all            # every Python install that has
                                             # a fileforge package or launcher
"""

from __future__ import annotations

import argparse
import glob
import os
import site
import sys
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def _default_wheel() -> Path:
    wheels = sorted(ROOT.glob("dist/locals_filesystem-*.whl"))
    if not wheels:
        wheels = sorted(ROOT.glob("dist/*.whl"))
    if not wheels:
        raise SystemExit("no wheel found in dist/ - run `python -m build` first")
    return wheels[-1]


def _site_packages(target: str | None) -> Path:
    if target:
        return Path(target)
    paths = site.getsitepackages() + ([site.getusersitepackages()]
                                      if hasattr(site, "getusersitepackages") else [])
    for p in paths:
        if (Path(p) / "fileforge").is_dir():
            return Path(p)
    return Path(site.getsitepackages()[0])


def _clear_pycache(pkg_dir: Path) -> int:
    removed = 0
    for pyc in glob.glob(str(pkg_dir / "__pycache__" / "*.pyc")):
        try:
            os.remove(pyc)
            removed += 1
        except OSError:
            pass
    return removed


def install(wheel: Path, target: Path) -> int:
    if not wheel.is_file():
        print(f"  ! missing wheel: {wheel}")
        return 1
    pkg = target / "fileforge"
    with zipfile.ZipFile(wheel) as zf:
        zf.extractall(target)
        modules = [n for n in zf.namelist()
                   if n.startswith("fileforge/") and n.endswith(".py")]
    cleared = _clear_pycache(pkg) if pkg.is_dir() else 0
    print(f"  {wheel.name}  ->  {target}")
    print(f"  {len(modules)} modules written, {cleared} stale .pyc removed")
    return 0


def _candidate_targets() -> list[Path]:
    """Every site-packages that already holds a `fileforge` package."""
    found: list[Path] = []
    seen: set[str] = set()
    roots = [
        Path(r) for r in (
            os.environ.get("LOCALAPPDATA", ""),
            os.environ.get("APPDATA", ""),
            os.environ.get("USERPROFILE", ""),
            "C:\\",
            "D:\\",
        ) if r
    ]
    patterns = ("**/site-packages/fileforge",)
    for root in roots:
        if not root.is_dir():
            continue
        for pat in patterns:
            for hit in root.glob(pat):
                if not hit.is_dir():
                    continue
                sp = hit.parent
                key = str(sp).lower()
                if key in seen:
                    continue
                seen.add(key)
                found.append(sp)
    return found


def main(argv: list[str]) -> int:
    ap = argparse.ArgumentParser(description=__doc__,
                                 formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--wheel", help="wheel to install (default: newest in dist/)")
    ap.add_argument("--target", help="site-packages directory")
    ap.add_argument("--all", action="store_true",
                    help="patch every Python install that has fileforge")
    args = ap.parse_args(argv)

    wheel = Path(args.wheel) if args.wheel else _default_wheel()

    if args.all:
        targets = _candidate_targets()
        if not targets:
            print("no installed fileforge packages found")
            return 1
        rc = 0
        for t in targets:
            rc |= install(wheel, t)
        return rc

    return install(wheel, _site_packages(args.target))


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
