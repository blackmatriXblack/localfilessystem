#!/usr/bin/env python3
"""Create `fileforge.cmd` / `fileforge-gui.cmd` console launchers.

pip cannot (re)generate console scripts in some sandboxed environments because
its rename-to-.deleteme write is intercepted by a safe-delete shim.  These two
batch files do exactly what the generated .exe would do:

    fileforge <args>      ->  python -m fileforge <args>
    fileforge-gui <args>  ->  pythonw -m fileforge gui <args>   (detached)

Run with the interpreter of the environment you want the command installed in:

    python make_launchers.py [scripts_dir]
"""

from __future__ import annotations

import os
import sys


def main(argv: list[str]) -> int:
    if argv:
        scripts = os.path.abspath(argv[0])
    else:
        scripts = os.path.join(os.path.dirname(sys.executable), "Scripts")
        if not os.path.isdir(scripts):
            scripts = os.path.dirname(sys.executable)

    py = os.path.join(scripts, "python.exe")
    pyw = os.path.join(scripts, "pythonw.exe")
    if not os.path.exists(py):
        py = sys.executable
    if not os.path.exists(pyw):
        pyw = py

    cli = os.path.join(scripts, "fileforge.cmd")
    gui = os.path.join(scripts, "fileforge-gui.cmd")

    with open(cli, "w", newline="") as fh:
        fh.write('@echo off\r\n"%s" -m fileforge %%*\r\n' % py)
    with open(gui, "w", newline="") as fh:
        fh.write('@echo off\r\nstart "" "%s" -m fileforge gui %%*\r\n' % pyw)

    print("wrote %s" % cli)
    print("wrote %s" % gui)
    print("  interpreter: %s" % py)
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
