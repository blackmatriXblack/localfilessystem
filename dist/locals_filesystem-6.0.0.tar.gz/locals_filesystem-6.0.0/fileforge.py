#!/usr/bin/env python3
"""
fileforge - single-file launcher (complete command registry)
============================================================

Runs the portable file-system toolkit from the repository root.

    python fileforge.py <command> [options]
    python fileforge.py help               # list every command
    python fileforge.py computerui         # "This PC" window (all drives)
    python fileforge.py shell
    python fileforge.py --help

Every command shipped by the toolkit is registered here:

  * the classic CLI commands (fileforge.cli)      - ls / find / grep / hash ...
  * the live file tree      (fileforge.treeview)  - tree / drives
  * the Tkinter explorer    (fileforge.treeui)    - treeui
  * the disk-usage chart    (fileforge.treemap)   - treemap
  * the whole-computer view (fileforge.computer,
                             fileforge.computerview) - computer / computerui

Aliases (pc, thispc, pcgui, explorer, ...) and typo correction
("computrui" -> "computerui") are handled as well.

Works on Linux, Windows and macOS with no third-party dependencies.
"""

from __future__ import annotations

import difflib
import os
import sys
from pathlib import Path

# Make the package importable no matter where the script is invoked from.
HERE = Path(__file__).resolve().parent
if str(HERE) not in sys.path:
    sys.path.insert(0, str(HERE))

# --- added: the package also lives under ./src (setuptools src-layout) ----
SRC = HERE / "src"
if SRC.is_dir() and str(SRC) not in sys.path:
    sys.path.insert(0, str(SRC))

# Best effort: force UTF-8 output on Windows terminals.
if os.name == "nt":
    try:
        sys.stdout.reconfigure(encoding="utf-8")  # type: ignore[attr-defined]
        sys.stderr.reconfigure(encoding="utf-8")  # type: ignore[attr-defined]
    except Exception:
        pass

APP = "fileforge"


# ==========================================================================
# Command catalogue: (group, [(name, one-line help), ...])
# ==========================================================================
CATALOG = [
    ("Browse & inspect", [
        ("ls",              "List directory contents"),
        ("tree",            "Live directory tree (no cache, streaming)"),
        ("tree-classic",    "Original ASCII tree from the classic CLI"),
        ("stat",            "Detailed metadata (mode, times, inode, MIME)"),
        ("filetype",        "Content-based MIME detection"),
        ("free",            "Free / used / total space on a volume"),
        ("drives",          "List all drives / mount points + free space"),
    ]),
    ("Whole computer (\"This PC\")", [
        ("computer",        "Print the entire machine as one tree"),
        ("computerui",      "Open the This PC window (all drives)"),
        ("treeui",          "Tkinter tree explorer (This PC when no path)"),
    ]),
    ("Disk usage", [
        ("treemap",         "Terminal disk-usage block map / bar chart"),
        ("du",              "Directory size breakdown"),
        ("largest",         "Largest files"),
        ("newest",          "Most recently modified files"),
        ("oldest",          "Least recently modified files"),
        ("empty",           "Empty files and directories"),
        ("broken-links",    "Dangling symlinks"),
        ("ext-summary",     "Count / size grouped by extension"),
        ("summary",         "One-shot report for a directory"),
    ]),
    ("File content", [
        ("cat",             "Print a file"),
        ("write",           "Write / append text to a file"),
        ("touch",           "Create an empty file or update mtime"),
        ("wc",              "Line / word / byte count"),
        ("replace",         "Find & replace (plain or regex, --dry-run)"),
        ("convert-encoding", "Re-encode a text file"),
    ]),
    ("Manage", [
        ("cp",              "Copy files / directories"),
        ("mv",              "Move or rename"),
        ("rm",              "Remove files / directories"),
        ("mkdir",           "Create directories"),
        ("rename",          "Rename one path"),
        ("rename-batch",    "Bulk rename with a pattern"),
        ("symlink",         "Create a symbolic link"),
        ("readlink",        "Resolve a symbolic link"),
    ]),
    ("Search", [
        ("find",            "Multi-criteria file search"),
        ("grep",            "Recursive content search"),
    ]),
    ("Integrity", [
        ("hash",            "Checksum one or more files"),
        ("manifest",        "Write a JSON checksum manifest"),
        ("verify",          "Verify a tree against a manifest"),
        ("compare",         "Byte-compare two files"),
        ("dupes",           "Find duplicate files"),
    ]),
    ("Archive & sync", [
        ("archive-create",  "Create zip / tar / tar.gz / tar.bz2 / tar.xz"),
        ("archive-extract", "Extract an archive (zip-slip safe)"),
        ("archive-list",    "List archive contents"),
        ("gzip",            "gzip / gunzip a single file"),
        ("split",           "Split a file into chunks"),
        ("merge",           "Rejoin chunks"),
        ("sync",            "Incremental mirror of a directory"),
    ]),
    ("Security", [
        ("chmod",           "Change permissions (octal or symbolic)"),
        ("perms",           "List permissions"),
        ("world-writable",  "Audit world-writable paths"),
        ("shred",           "Secure delete (overwrite then unlink)"),
        ("encrypt",         "Encrypt a file with a passphrase"),
        ("decrypt",         "Decrypt a file"),
    ]),
    ("Applications", [
        ("gui",             "Full Tkinter GUI (8 tabs)"),
        ("shell",           "Interactive shell (cd/pwd/history/!cmd)"),
        ("help",            "Show this command list"),
    ]),
]

# Aliases -> canonical command name.
ALIASES = {
    "tree-gui": "treeui",
    "explorer": "treeui",
    "pc": "computer",
    "thispc": "computer",
    "this-pc": "computer",
    "mycomputer": "computer",
    "pcgui": "computerui",
    "pcui": "computerui",
    "thispcui": "computerui",
    "this-pc-ui": "computerui",
    "computer-gui": "computerui",
    "roots": "drives",
    "mounts": "drives",
    "volumes": "drives",
    "map": "treemap",
    "diskmap": "treemap",
    "du-map": "treemap",
}

# Commands implemented inside fileforge.cli (the classic 40+ command set).
CLASSIC_COMMANDS = {
    "ls", "find", "grep", "cat", "write", "touch", "cp", "mv", "rm", "mkdir",
    "rename", "rename-batch", "hash", "manifest", "verify", "compare", "dupes",
    "du", "largest", "newest", "oldest", "empty", "broken-links",
    "ext-summary", "summary", "archive-create", "archive-extract",
    "archive-list", "gzip", "split", "merge", "sync", "chmod", "perms",
    "world-writable", "shred", "encrypt", "decrypt", "wc", "replace",
    "convert-encoding", "symlink", "readlink", "stat", "filetype", "free",
    "shell", "gui",
}

# Kept for backwards compatibility with earlier revisions of this launcher.
TREE_COMMANDS = {"tree", "treeui", "tree-gui", "treemap", "drives", "roots",
                 "computer", "pc", "thispc", "computerui", "pcgui"}


def _all_names():
    names = []
    for _group, entries in CATALOG:
        names.extend(name for name, _help in entries)
    return names


def _bootstrap() -> int:
    try:
        from fileforge.cli import main
    except ImportError as exc:  # pragma: no cover
        print(f"fileforge: failed to import package: {exc}", file=sys.stderr)
        return 1
    return main(sys.argv[1:])


# --------------------------------------------------------------------------
# Live-tree / whole-computer handlers
# --------------------------------------------------------------------------
def _classic(argv) -> int:
    """Delegate to the classic argparse CLI (never back to ``cli.main``)."""
    from fileforge import cli as cli_mod
    handler = getattr(cli_mod, "main_classic", None) or cli_mod.main
    return handler(argv)


def _run_tree(rest) -> int:
    from fileforge.treeview import main as tree_main
    return tree_main(rest)


def _run_treemap(rest) -> int:
    from fileforge.treemap import main as treemap_main
    return treemap_main(rest)


def _run_treeui(rest) -> int:
    """Path given -> folder explorer.  No path -> whole computer."""
    if any(not a.startswith("-") for a in rest):
        from fileforge.treeui import main as treeui_main
        return treeui_main(rest)
    from fileforge.computerview import main as pc_main
    return pc_main(rest)


def _run_computer(rest) -> int:
    from fileforge.computer import main as computer_main
    return computer_main(rest)


def _run_computerui(rest) -> int:
    from fileforge.computerview import main as pc_main
    return pc_main(rest)


def _show_roots() -> int:
    from fileforge.treeview import system_roots
    from fileforge.utils import free_space, human_size

    roots = system_roots()
    print(f"Mount points / drives on this machine ({len(roots)}):")
    for root in roots:
        try:
            total, _used, free = free_space(Path(root))
            print(f"  {root:<24} free {human_size(free):>10} "
                  f"of {human_size(total):>10}")
        except OSError:
            print(f"  {root:<24} (unavailable)")
    return 0


def _print_catalog(stream=None) -> None:
    out = stream or sys.stdout
    out.write(f"{APP} - portable local file-system toolkit\n")
    out.write("Usage: python fileforge.py <command> [options]\n")
    out.write("       python fileforge.py help              show this list\n")
    out.write("       python fileforge.py <command> --help  "
              "options for one command\n\n")
    width = max(len(n) for _g, entries in CATALOG for n, _h in entries)
    for group, entries in CATALOG:
        out.write(f"{group}\n")
        for name, help_text in entries:
            extra = "".join(f" /{a}" for a, t in ALIASES.items() if t == name)
            out.write(f"  {name:<{width}}  {help_text}{extra}\n")
        out.write("\n")
    out.write("Tip: every command supports --help.  Typos are auto-corrected\n")
    out.write("     (e.g. `computrui` runs `computerui`).\n")


def _dispatch(args) -> int:
    """Full dispatcher.  Returns an exit code."""
    if not args or args[0] in ("help", "commands"):
        _print_catalog()
        return 0
    if args[0] in ("--version", "-V"):
        from fileforge import __version__
        print(f"{APP} {__version__}")
        return 0

    cmd, rest = args[0], list(args[1:])
    cmd = ALIASES.get(cmd, cmd)

    try:
        if cmd in ("-h", "--help"):
            _print_catalog()
            return 0
        if cmd == "tree-classic":
            return _classic(["tree"] + rest)
        if cmd == "tree":
            return _run_tree(rest)
        if cmd == "treeui":
            return _run_treeui(rest)
        if cmd == "treemap":
            return _run_treemap(rest)
        if cmd == "drives":
            return _show_roots()
        if cmd == "computer":
            return _run_computer(rest)
        if cmd == "computerui":
            return _run_computerui(rest)
        if cmd in CLASSIC_COMMANDS:
            return _classic([cmd] + rest)
    except ImportError as exc:
        print(f"{APP}: '{cmd}' needs the fileforge package ({exc})",
              file=sys.stderr)
        print(f"{APP}: GUI commands need tkinter "
              f"(Linux: sudo apt install python3-tk)", file=sys.stderr)
        return 1
    except KeyboardInterrupt:
        print("\ninterrupted", file=sys.stderr)
        return 130

    # Unknown command - suggest and, when obvious, just run it.
    known = sorted(set(_all_names()) | set(ALIASES))
    matches = difflib.get_close_matches(cmd, known, n=1, cutoff=0.7)
    if matches:
        guess = ALIASES.get(matches[0], matches[0])
        if difflib.SequenceMatcher(None, cmd, guess).ratio() >= 0.8:
            print(f"{APP}: interpreting '{cmd}' as '{guess}'", file=sys.stderr)
            return _dispatch([guess] + rest)
        print(f"{APP}: unknown command '{cmd}' (did you mean '{guess}'?)",
              file=sys.stderr)
    else:
        print(f"{APP}: unknown command '{cmd}'", file=sys.stderr)
    print(f"{APP}: run '{APP} help' to see all commands.", file=sys.stderr)
    return 2


if __name__ == "__main__":
    sys.exit(_dispatch(sys.argv[1:]))
